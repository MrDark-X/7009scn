<?php
// Database configuration via environment variables
$servername = getenv('DB_HOST');
$username   = getenv('DB_USER');
$password   = getenv('DB_PASSWORD');
$dbname     = getenv('DB_NAME');

// Basic sanity check – in a real system you’d log this, not echo
if (!$servername || !$username || !$password || !$dbname) {
    die('Database configuration is missing. Please check environment variables.');
}

// Create connection with error handling
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    // Do not expose internal details to user
    die('Database connection failed. Please contact the administrator.');
}

// Prepare and execute the query safely
$sql  = "SELECT fullname, suggestion FROM suggestion ORDER BY id DESC";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    $conn->close();
    die('Internal error while preparing query.');
}

if (!$stmt->execute()) {
    $stmt->close();
    $conn->close();
    die('Internal error while querying suggestions.');
}

$stmt->bind_result($cuser, $csuggestion);

// Build HTML output
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Staff Suggestions</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Staff Suggestions</h1>
    <h3>Share your constructive ideas to improve our workplace!</h3>

    <form action="action.php" method="post">
        <label for="fullname">Username:</label><br>
        <input type="text" id="fullname" name="fullname" required><br>

        <label for="suggestion">Suggestion:</label><br>
        <textarea id="suggestion" name="suggestion" rows="5" required></textarea><br><br>

        <button type="submit">Submit Suggestion</button>
    </form>

    <p>Submit your suggestions to help us create a better working environment.</p>

    <table class="suggestions-table">
        <thead>
        <tr>
            <th>User</th>
            <th>Suggestion</th>
        </tr>
        </thead>
        <tbody>
        <?php while ($stmt->fetch()): ?>
            <tr>
                <td><?php echo htmlspecialchars($cuser, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); ?></td>
                <td><?php echo nl2br(htmlspecialchars($csuggestion, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')); ?></td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>
<?php
$stmt->close();
$conn->close();

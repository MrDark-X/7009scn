<?php
// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /index.php');
    exit;
}

// Database configuration via environment variables
$servername = getenv('DB_HOST');
$username   = getenv('DB_USER');
$password   = getenv('DB_PASSWORD');
$dbname     = getenv('DB_NAME');

if (!$servername || !$username || !$password || !$dbname) {
    die('Database configuration is missing. Please contact the administrator.');
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die('Database connection failed. Please try again later.');
}

// Fetch and validate POST data
$fullnamedata    = isset($_POST['fullname'])   ? trim($_POST['fullname'])   : '';
$suggestiondata  = isset($_POST['suggestion']) ? trim($_POST['suggestion']) : '';

if ($fullnamedata === '' || $suggestiondata === '') {
    $conn->close();
    die('Both name and suggestion are required.');
}

// Simple length checks to prevent abuse
if (mb_strlen($fullnamedata) > 64) {
    $conn->close();
    die('Name is too long (max 64 characters).');
}

// Insert using prepared statement
$stmt = $conn->prepare("INSERT INTO suggestion (fullname, suggestion) VALUES (?, ?)");
if (!$stmt) {
    $conn->close();
    die('Failed to prepare insert statement.');
}

if (!$stmt->bind_param("ss", $fullnamedata, $suggestiondata)) {
    $stmt->close();
    $conn->close();
    die('Failed to bind data to statement.');
}

if (!$stmt->execute()) {
    // In production, you would log $stmt->error instead of echoing
    $stmt->close();
    $conn->close();
    die('Unexpected error while saving your suggestion. Please try again later.');
}

$stmt->close();
$conn->close();

// Redirect back to main page after successful submission
header('Location: /index.php');
exit;

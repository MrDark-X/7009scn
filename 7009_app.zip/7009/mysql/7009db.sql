-- Create database if it does not already exist
CREATE DATABASE IF NOT EXISTS 7009db;
USE 7009db;

-- Suggestion table for staff suggestions
DROP TABLE IF EXISTS suggestion;

CREATE TABLE suggestion (
  id INT(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  fullname VARCHAR(64) NOT NULL,
  suggestion LONGTEXT NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed example data
INSERT INTO suggestion (fullname, suggestion) VALUES
  ('Anonymous', 'Provide free chocolate in the offices'),
  ('Dr B', 'Free copies of BTTF as Christmas bonuses');

USE 7009db;

DROP TABLE IF EXISTS suggestion;

CREATE TABLE suggestion (
  id INT(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  fullname VARCHAR(64) DEFAULT NULL,
  suggestion LONGTEXT DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO suggestion (fullname, suggestion)
VALUES
  ('Anonymous','Provide free chocolate in the offices'),
  ('Dr B','Free copies of BTTF as xmas bonuses');
